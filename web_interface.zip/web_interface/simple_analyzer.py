#!/usr/bin/env python3

import os
import json
from pathlib import Path

class SimpleProjectAnalyzer:
    """Простой и рабочий анализатор проектов"""
    
    def analyze(self, project_path):
        """Анализирует проект и возвращает информацию"""
        result = {
            'language': 'unknown',
            'framework': 'unknown',
            'type': 'unknown',
            'complexity': 'low',
            'testing': False,
            'dependencies': [],
            'structure': {
                'monorepo': False,
                'microservices': False,
                'layered': False,
                'modular': False,
                'dockerized': False
            }
        }
        
        try:
            # Сначала проверим, что есть в директории
            files_in_dir = os.listdir(project_path)
            print(f"Files in project directory: {files_in_dir}")
            
            # Проверяем package.json (Node.js/JavaScript)
            package_json_path = os.path.join(project_path, 'package.json')
            if os.path.exists(package_json_path):
                print(f"Found package.json at {package_json_path}")
                with open(package_json_path, 'r') as f:
                    package_data = json.load(f)
                print(f"Package.json content: {package_data}")
                
                result['language'] = 'javascript'
                result['type'] = 'frontend'
                result['dependencies'] = list(package_data.get('dependencies', {}).keys())
                
                # Определяем фреймворк
                deps = {**package_data.get('dependencies', {}), **package_data.get('devDependencies', {})}
                if 'react' in deps:
                    result['framework'] = 'react'
                elif 'vue' in deps:
                    result['framework'] = 'vue'
                elif 'angular' in deps or '@angular/core' in deps:
                    result['framework'] = 'angular'
                elif 'express' in deps:
                    result['framework'] = 'express'
                    result['type'] = 'backend'
                else:
                    result['framework'] = 'nodejs'
                
                # Проверяем тесты
                if any('test' in script.lower() for script in package_data.get('scripts', {}).values()):
                    result['testing'] = True
                
                # Проверяем сложность
                total_deps = len(result['dependencies'])
                if total_deps > 20:
                    result['complexity'] = 'high'
                elif total_deps > 10:
                    result['complexity'] = 'medium'
            
            # Проверяем requirements.txt (Python)
            elif os.path.exists(os.path.join(project_path, 'requirements.txt')):
                result['language'] = 'python'
                result['type'] = 'backend'
                
                with open(os.path.join(project_path, 'requirements.txt'), 'r') as f:
                    deps = [line.strip() for line in f if line.strip() and not line.startswith('#')]
                    result['dependencies'] = deps
                
                # Определяем фреймворк
                if any('django' in dep.lower() for dep in deps):
                    result['framework'] = 'django'
                elif any('flask' in dep.lower() for dep in deps):
                    result['framework'] = 'flask'
                elif any('fastapi' in dep.lower() for dep in deps):
                    result['framework'] = 'fastapi'
                else:
                    result['framework'] = 'python'
                
                # Проверяем тесты
                if any('pytest' in dep.lower() or 'test' in dep.lower() for dep in deps):
                    result['testing'] = True
                
                # Проверяем сложность
                if len(deps) > 15:
                    result['complexity'] = 'high'
                elif len(deps) > 8:
                    result['complexity'] = 'medium'
            
            # Проверяем go.mod (Go)
            elif os.path.exists(os.path.join(project_path, 'go.mod')):
                result['language'] = 'go'
                result['type'] = 'backend'
                result['framework'] = 'go'
                
                with open(os.path.join(project_path, 'go.mod'), 'r') as f:
                    content = f.read()
                    if 'gin-gonic/gin' in content:
                        result['framework'] = 'gin'
                    elif 'labstack/echo' in content:
                        result['framework'] = 'echo'
            
            # Проверяем pom.xml (Java)
            elif os.path.exists(os.path.join(project_path, 'pom.xml')):
                result['language'] = 'java'
                result['type'] = 'backend'
                result['framework'] = 'spring-boot'
            
            # Проверяем composer.json (PHP)
            elif os.path.exists(os.path.join(project_path, 'composer.json')):
                result['language'] = 'php'
                result['type'] = 'backend'
                result['framework'] = 'laravel'
            
            # Проверяем Dockerfile
            if os.path.exists(os.path.join(project_path, 'Dockerfile')):
                result['structure']['dockerized'] = True
            
            # Проверяем тестовые файлы
            test_files = []
            for root, dirs, files in os.walk(project_path):
                for file in files:
                    if any(pattern in file.lower() for pattern in ['test', 'spec', '__tests__']):
                        test_files.append(file)
            
            if test_files:
                result['testing'] = True
            
            print(f"✅ Анализ завершен: {result['language']} - {result['framework']}")
            
        except Exception as e:
            print(f"❌ Ошибка анализа: {e}")
        
        return result
