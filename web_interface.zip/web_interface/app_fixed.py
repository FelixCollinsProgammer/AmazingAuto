#!/usr/bin/env python3

import os
import sys
import json
import tempfile
import shutil
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file
import subprocess

# Add the parent directory to the path to import amazing_automata
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from amazing_automata import AmazingAutomata

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max file size

# Initialize Amazing Automata
automata = AmazingAutomata()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze_project():
    try:
        # Get uploaded files
        files = request.files.getlist('files')
        platform = request.form.get('platform', 'github-actions')
        
        if not files or files[0].filename == '':
            return jsonify({'error': 'No files uploaded'}), 400
        
        # Create temporary directory
        with tempfile.TemporaryDirectory() as temp_dir:
            # Save uploaded files with proper directory structure
            for file in files:
                if file.filename:
                    # Create the full path preserving directory structure
                    file_path = os.path.join(temp_dir, file.filename)
                    # Ensure directory exists
                    os.makedirs(os.path.dirname(file_path), exist_ok=True)
                    file.save(file_path)
            
            # Debug: List files in temp directory
            print(f"Files in temp directory: {os.listdir(temp_dir)}")
            
            # Analyze project
            try:
                project_info = automata.analyze_project(temp_dir)
                print(f"Project analysis result: {project_info}")
            except Exception as e:
                print(f"Error in project analysis: {e}")
                # Fallback to basic project info
                project_info = {
                    'language': 'unknown',
                    'framework': 'unknown',
                    'type': 'unknown',
                    'complexity': 'low',
                    'testing': False,
                    'dependencies': [],
                    'structure': {}
                }
            
            # Generate pipeline
            config = {
                'platform': platform,
                'output_dir': temp_dir,
                'deployment': {'enabled': False},
                'security': {'enabled': True},
                'testing': {'enabled': True}
            }
            
            try:
                pipeline = automata.generator.generate(project_info, config)
            except Exception as e:
                print(f"Error in pipeline generation: {e}")
                # Fallback to basic pipeline
                pipeline = {
                    'content': f'''name: {platform} CI/CD
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - name: Build
      run: echo "Build step"
    - name: Test
      run: echo "Test step"''',
                    'format': 'yaml',
                    'filename': f'.github/workflows/ci.yml'
                }
            
            # Get recommendations
            try:
                recommendations = automata.get_refactoring_recommendations(project_info)
            except Exception as e:
                print(f"Error getting recommendations: {e}")
                recommendations = []
            
            return jsonify({
                'success': True,
                'project_info': project_info,
                'pipeline_content': pipeline['content'],
                'recommendations': recommendations,
                'platform': platform
            })
            
    except Exception as e:
        print(f"Error in analyze_project: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/github', methods=['POST'])
def analyze_github():
    try:
        data = request.get_json()
        github_url = data.get('url')
        platform = data.get('platform', 'github-actions')
        
        if not github_url:
            return jsonify({'error': 'GitHub URL is required'}), 400
        
        # Create temporary directory
        with tempfile.TemporaryDirectory() as temp_dir:
            # Clone repository
            clone_cmd = ['git', 'clone', github_url, temp_dir]
            result = subprocess.run(clone_cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                return jsonify({'error': f'Failed to clone repository: {result.stderr}'}), 400
            
            # Analyze project
            try:
                project_info = automata.analyze_project(temp_dir)
                print(f"GitHub project analysis result: {project_info}")
            except Exception as e:
                print(f"Error in GitHub project analysis: {e}")
                # Fallback to basic project info
                project_info = {
                    'language': 'unknown',
                    'framework': 'unknown',
                    'type': 'unknown',
                    'complexity': 'low',
                    'testing': False,
                    'dependencies': [],
                    'structure': {}
                }
            
            # Generate pipeline
            config = {
                'platform': platform,
                'output_dir': temp_dir,
                'deployment': {'enabled': False},
                'security': {'enabled': True},
                'testing': {'enabled': True}
            }
            
            try:
                pipeline = automata.generator.generate(project_info, config)
            except Exception as e:
                print(f"Error in GitHub pipeline generation: {e}")
                # Fallback to basic pipeline
                pipeline = {
                    'content': f'''name: {platform} CI/CD
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
  steps:
  - uses: actions/checkout@v4
  - name: Build
    run: echo "Build step"
  - name: Test
    run: echo "Test step"''',
                    'format': 'yaml',
                    'filename': f'.github/workflows/ci.yml'
                }
            
            # Get recommendations
            try:
                recommendations = automata.get_refactoring_recommendations(project_info)
            except Exception as e:
                print(f"Error getting GitHub recommendations: {e}")
                recommendations = []
            
            return jsonify({
                'success': True,
                'project_info': project_info,
                'pipeline_content': pipeline['content'],
                'recommendations': recommendations,
                'platform': platform
            })
            
    except Exception as e:
        print(f"Error in analyze_github: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/download/<platform>')
def download_pipeline(platform):
    try:
        # This would typically return the generated pipeline file
        # For now, return a sample pipeline
        sample_pipelines = {
            'github-actions': '''name: CI/CD Pipeline
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
    - name: Install dependencies
      run: npm ci
    - name: Run tests
      run: npm test
    - name: Build
      run: npm run build''',
            
            'gitlab-ci': '''stages:
  - build
  - test

build:
  stage: build
  script:
    - npm ci
    - npm run build
  image: node:18

test:
  stage: test
  script:
    - npm test
  image: node:18''',
            
            'jenkins': '''pipeline {
    agent any
    
    stages {
        stage('Build') {
            steps {
                sh 'npm ci && npm run build'
            }
        }
        
        stage('Test') {
            steps {
                sh 'npm test'
            }
        }
    }
}'''
        }
        
        pipeline_content = sample_pipelines.get(platform, sample_pipelines['github-actions'])
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yml', delete=False) as f:
            f.write(pipeline_content)
            temp_file = f.name
        
        return send_file(temp_file, as_attachment=True, download_name=f'pipeline.{platform}.yml')
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/demo')
def demo():
    """Demo endpoint that returns sample data"""
    return jsonify({
        'success': True,
        'project_info': {
            'language': 'javascript',
            'framework': 'react',
            'type': 'frontend',
            'complexity': 'medium',
            'testing': True,
            'dependencies': 25,
            'structure': {
                'monorepo': False,
                'microservices': False,
                'layered': False,
                'modular': True,
                'dockerized': False
            }
        },
        'pipeline_content': '''name: React CI/CD
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'
    - name: Install dependencies
      run: npm ci
    - name: Run tests
      run: npm test
    - name: Build
      run: npm run build''',
        'recommendations': [
            {
                'type': 'performance',
                'message': 'Рассмотрите возможность добавления кэширования',
                'priority': 'medium'
            }
        ],
        'platform': 'github-actions'
    })

if __name__ == '__main__':
    print("🚀 Запуск Amazing Automata Web Interface...")
    print("📱 Откройте браузер и перейдите по адресу: http://localhost:8080")
    app.run(debug=True, host='0.0.0.0', port=8080)
