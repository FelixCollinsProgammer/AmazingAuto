#!/usr/bin/env python3

class SimplePipelineGenerator:
    """Простой генератор пайплайнов"""
    
    def generate(self, project_info, platform='github-actions'):
        """Генерирует пайплайн для проекта"""
        
        language = project_info.get('language', 'unknown')
        framework = project_info.get('framework', 'unknown')
        testing = project_info.get('testing', False)
        
        if platform == 'github-actions':
            return self.generate_github_actions(language, framework, testing)
        elif platform == 'gitlab-ci':
            return self.generate_gitlab_ci(language, framework, testing)
        elif platform == 'jenkins':
            return self.generate_jenkins(language, framework, testing)
        else:
            return self.generate_github_actions(language, framework, testing)
    
    def generate_github_actions(self, language, framework, testing):
        """Генерирует GitHub Actions пайплайн"""
        
        if language == 'javascript':
            if framework == 'react':
                return f'''name: React CI/CD
on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'
    - name: Install dependencies
      run: npm ci
    - name: Run tests
      run: npm test
    - name: Build
      run: npm run build'''
            
            elif framework == 'express':
                return f'''name: Express.js CI/CD
on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'
    - name: Install dependencies
      run: npm ci
    - name: Run tests
      run: npm test
    - name: Build
      run: npm run build'''
            
            else:
                return f'''name: Node.js CI/CD
on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'
    - name: Install dependencies
      run: npm ci
    - name: Run tests
      run: npm test
    - name: Build
      run: npm run build'''
        
        elif language == 'python':
            if framework == 'django':
                return f'''name: Django CI/CD
on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    - name: Setup Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.9'
    - name: Install dependencies
      run: pip install -r requirements.txt
    - name: Run tests
      run: python manage.py test
    - name: Build
      run: python manage.py collectstatic --noinput'''
            
            elif framework == 'flask':
                return f'''name: Flask CI/CD
on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    - name: Setup Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.9'
    - name: Install dependencies
      run: pip install -r requirements.txt
    - name: Run tests
      run: python -m pytest
    - name: Build
      run: echo "Flask build complete"'''
            
            else:
                return f'''name: Python CI/CD
on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    - name: Setup Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.9'
    - name: Install dependencies
      run: pip install -r requirements.txt
    - name: Run tests
      run: python -m pytest
    - name: Build
      run: echo "Python build complete"'''
        
        elif language == 'go':
            return f'''name: Go CI/CD
on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    - name: Setup Go
      uses: actions/setup-go@v4
      with:
        go-version: '1.21'
    - name: Install dependencies
      run: go mod download
    - name: Run tests
      run: go test ./...
    - name: Build
      run: go build -o app ./...'''
        
        else:
            return f'''name: Universal CI/CD
on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    - name: Build
      run: echo "Build step"
    - name: Test
      run: echo "Test step"'''
    
    def generate_gitlab_ci(self, language, framework, testing):
        """Генерирует GitLab CI пайплайн"""
        return f'''stages:
  - build
  - test
  - deploy

variables:
  NODE_VERSION: "18"
  PYTHON_VERSION: "3.9"
  GO_VERSION: "1.21"

build:
  stage: build
  script:
    - echo "Build step"
  image: ubuntu:latest

test:
  stage: test
  script:
    - echo "Test step"
  image: ubuntu:latest'''
    
    def generate_jenkins(self, language, framework, testing):
        """Генерирует Jenkins пайплайн"""
        return f'''pipeline {{
    agent any
    
    stages {{
        stage('Build') {{
            steps {{
                sh 'echo "Build step"'
            }}
        }}
        
        stage('Test') {{
            steps {{
                sh 'echo "Test step"'
            }}
        }}
    }}
    
    post {{
        always {{
            publishTestResults testResultsPattern: '**/test-results.xml'
        }}
    }}
}}'''
