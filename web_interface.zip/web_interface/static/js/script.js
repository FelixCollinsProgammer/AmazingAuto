// Amazing Automata Web Interface JavaScript

class AmazingAutomataWeb {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupUploadOptions();
        this.setupSmoothScrolling();
    }

    setupEventListeners() {
        // Upload form submission
        document.getElementById('uploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleFormSubmission();
        });

        // File input change
        document.getElementById('folderInput').addEventListener('change', (e) => {
            this.handleFileSelection(e);
        });

        // GitHub URL input
        document.getElementById('githubUrl').addEventListener('input', (e) => {
            this.handleGitHubUrl(e);
        });

        // Fetch GitHub button
        document.querySelector('.btn-fetch').addEventListener('click', (e) => {
            this.fetchGitHubRepo();
        });
    }

    setupUploadOptions() {
        const uploadOptions = document.querySelectorAll('.upload-option');
        
        uploadOptions.forEach(option => {
            option.addEventListener('click', (e) => {
                // Remove active class from all options
                uploadOptions.forEach(opt => opt.classList.remove('active'));
                
                // Add active class to clicked option
                option.classList.add('active');
                
                // Show/hide appropriate inputs
                const type = option.dataset.type;
                this.toggleInputs(type);
            });
        });
    }

    toggleInputs(type) {
        const folderInput = document.querySelector('.folder-input');
        const githubInput = document.querySelector('.github-input');
        
        if (type === 'folder') {
            folderInput.style.display = 'block';
            githubInput.style.display = 'none';
        } else {
            folderInput.style.display = 'none';
            githubInput.style.display = 'flex';
        }
    }

    setupSmoothScrolling() {
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    handleFileSelection(event) {
        const files = event.target.files;
        if (files.length > 0) {
            const label = document.querySelector('.file-label span');
            label.textContent = `Выбрано файлов: ${files.length}`;
            
            // Add visual feedback
            const fileLabel = document.querySelector('.file-label');
            fileLabel.style.background = '#667eea';
            fileLabel.style.color = 'white';
        }
    }

    handleGitHubUrl(event) {
        const url = event.target.value;
        const fetchBtn = document.querySelector('.btn-fetch');
        
        if (this.isValidGitHubUrl(url)) {
            fetchBtn.style.background = '#28a745';
            fetchBtn.textContent = 'Получить проект';
        } else {
            fetchBtn.style.background = '#667eea';
            fetchBtn.textContent = 'Получить проект';
        }
    }

    isValidGitHubUrl(url) {
        const githubRegex = /^https:\/\/github\.com\/[a-zA-Z0-9_-]+\/[a-zA-Z0-9_-]+$/;
        return githubRegex.test(url);
    }

    async fetchGitHubRepo() {
        const url = document.getElementById('githubUrl').value;
        
        if (!this.isValidGitHubUrl(url)) {
            this.showNotification('Пожалуйста, введите корректный GitHub URL', 'error');
            return;
        }

        const fetchBtn = document.querySelector('.btn-fetch');
        const originalText = fetchBtn.textContent;
        
        fetchBtn.innerHTML = '<div class="loading"></div> Получение...';
        fetchBtn.disabled = true;

        try {
            // Simulate GitHub repo fetching
            await this.simulateDelay(2000);
            
            this.showNotification('Репозиторий успешно получен!', 'success');
            this.showProjectPreview(url);
        } catch (error) {
            this.showNotification('Ошибка при получении репозитория', 'error');
        } finally {
            fetchBtn.textContent = originalText;
            fetchBtn.disabled = false;
        }
    }

    async handleFormSubmission() {
        const form = document.getElementById('uploadForm');
        const generateBtn = document.querySelector('.btn-generate');
        const originalText = generateBtn.innerHTML;
        
        // Show loading state
        generateBtn.innerHTML = '<div class="loading"></div> Анализируем проект...';
        generateBtn.disabled = true;

        try {
            // Get form data
            const formData = new FormData(form);
            const platform = formData.get('platform') || 'github-actions';
            
            // Check if it's folder upload or GitHub URL
            const activeOption = document.querySelector('.upload-option.active');
            const uploadType = activeOption.dataset.type;
            
            let results;
            
            if (uploadType === 'folder') {
                // Handle folder upload
                const files = document.getElementById('folderInput').files;
                if (files.length === 0) {
                    this.showNotification('Пожалуйста, выберите папку с проектом', 'error');
                    return;
                }
                
                results = await this.analyzeProject(files, platform);
            } else {
                // Handle GitHub URL
                const githubUrl = document.getElementById('githubUrl').value;
                if (!githubUrl) {
                    this.showNotification('Пожалуйста, введите GitHub URL', 'error');
                    return;
                }
                
                results = await this.analyzeGitHub(githubUrl, platform);
            }
            
            // Show results
            this.showResults(results);
            
            this.showNotification('Пайплайн успешно сгенерирован!', 'success');
            
        } catch (error) {
            console.error('Error:', error);
            this.showNotification('Ошибка при анализе проекта: ' + error.message, 'error');
        } finally {
            generateBtn.innerHTML = originalText;
            generateBtn.disabled = false;
        }
    }

    async analyzeProject(files, platform) {
        const formData = new FormData();
        formData.append('platform', platform);
        
        // Add files to form data
        for (let file of files) {
            formData.append('files', file);
        }
        
        const response = await fetch('/api/analyze', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Ошибка при анализе проекта');
        }
        
        return await response.json();
    }

    async analyzeGitHub(url, platform) {
        const response = await fetch('/api/github', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                url: url,
                platform: platform
            })
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Ошибка при анализе GitHub репозитория');
        }
        
        return await response.json();
    }

    async simulateAnalysis() {
        // Simulate different project types
        const projectTypes = [
            {
                language: 'javascript',
                framework: 'react',
                type: 'frontend',
                complexity: 'medium',
                testing: true,
                dependencies: 25
            },
            {
                language: 'python',
                framework: 'flask',
                type: 'backend',
                complexity: 'low',
                testing: true,
                dependencies: 8
            },
            {
                language: 'go',
                framework: 'gin',
                type: 'backend',
                complexity: 'medium',
                testing: true,
                dependencies: 12
            }
        ];

        const randomProject = projectTypes[Math.floor(Math.random() * projectTypes.length)];
        
        return {
            project: randomProject,
            recommendations: this.generateRecommendations(randomProject),
            pipeline: this.generatePipelineCode(randomProject)
        };
    }

    generateRecommendations(project) {
        const recommendations = [];
        
        if (!project.testing) {
            recommendations.push({
                type: 'testing',
                message: 'Рекомендуется добавить тестирование',
                priority: 'high'
            });
        }
        
        if (project.complexity === 'high') {
            recommendations.push({
                type: 'complexity',
                message: 'Проект имеет высокую сложность. Рассмотрите разбиение на микросервисы',
                priority: 'medium'
            });
        }
        
        if (project.dependencies > 50) {
            recommendations.push({
                type: 'dependencies',
                message: 'Большое количество зависимостей. Проверьте актуальность',
                priority: 'low'
            });
        }
        
        return recommendations;
    }

    generatePipelineCode(project) {
        const platform = document.querySelector('input[name="platform"]:checked').value;
        
        if (platform === 'github-actions') {
            return this.generateGitHubActionsPipeline(project);
        } else if (platform === 'gitlab-ci') {
            return this.generateGitLabCIPipeline(project);
        } else {
            return this.generateJenkinsPipeline(project);
        }
    }

    generateGitHubActionsPipeline(project) {
        return `name: ${project.framework} CI/CD
on:
  push:
    branches: [ main, master, develop ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout
      uses: actions/checkout@v4
    - name: Setup ${project.language === 'javascript' ? 'Node.js' : project.language === 'python' ? 'Python' : 'Go'}
      uses: ${project.language === 'javascript' ? 'actions/setup-node@v4' : project.language === 'python' ? 'actions/setup-python@v4' : 'actions/setup-go@v4'}
      with:
        ${project.language === 'javascript' ? 'node-version: 18' : project.language === 'python' ? 'python-version: 3.9' : 'go-version: 1.21'}
    - name: Install dependencies
      run: ${project.language === 'javascript' ? 'npm ci' : project.language === 'python' ? 'pip install -r requirements.txt' : 'go mod download'}
    - name: Run tests
      run: ${project.language === 'javascript' ? 'npm test' : project.language === 'python' ? 'python -m pytest' : 'go test ./...'}
    - name: Build
      run: ${project.language === 'javascript' ? 'npm run build' : project.language === 'python' ? 'echo "Python build complete"' : 'go build -o app ./...'}`;
    }

    generateGitLabCIPipeline(project) {
        return `stages:
  - build
  - test
  - deploy

variables:
  NODE_VERSION: "18"
  PYTHON_VERSION: "3.9"
  GO_VERSION: "1.21"

build:
  stage: build
  script:
    - ${project.language === 'javascript' ? 'npm ci && npm run build' : project.language === 'python' ? 'pip install -r requirements.txt' : 'go mod download && go build ./...'}
  image: ${project.language === 'javascript' ? 'node:18' : project.language === 'python' ? 'python:3.9' : 'golang:1.21'}

test:
  stage: test
  script:
    - ${project.language === 'javascript' ? 'npm test' : project.language === 'python' ? 'python -m pytest' : 'go test ./...'}
  image: ${project.language === 'javascript' ? 'node:18' : project.language === 'python' ? 'python:3.9' : 'golang:1.21'}`;
    }

    generateJenkinsPipeline(project) {
        return `pipeline {
    agent any
    
    stages {
        stage('Build') {
            steps {
                sh '${project.language === 'javascript' ? 'npm ci && npm run build' : project.language === 'python' ? 'pip install -r requirements.txt' : 'go mod download && go build ./...'}'
            }
        }
        
        stage('Test') {
            steps {
                sh '${project.language === 'javascript' ? 'npm test' : project.language === 'python' ? 'python -m pytest' : 'go test ./...'}'
            }
        }
    }
    
    post {
        always {
            publishTestResults testResultsPattern: '**/test-results.xml'
        }
    }
}`;
    }

    showResults(results) {
        // Show results section
        document.getElementById('results').style.display = 'block';
        
        // Populate project info
        const projectInfo = document.getElementById('projectInfo');
        const project = results.project_info || results.project;
        
        // Format language display
        const languageDisplay = project.language === 'unknown' ? 'Не определен' : project.language;
        const frameworkDisplay = project.framework === 'unknown' ? 'Не определен' : project.framework;
        const typeDisplay = project.type === 'unknown' ? 'Не определен' : project.type;
        
        projectInfo.innerHTML = `
            <div class="info-item">
                <strong>Язык:</strong> <span class="info-value">${languageDisplay}</span>
            </div>
            <div class="info-item">
                <strong>Фреймворк:</strong> <span class="info-value">${frameworkDisplay}</span>
            </div>
            <div class="info-item">
                <strong>Тип:</strong> <span class="info-value">${typeDisplay}</span>
            </div>
            <div class="info-item">
                <strong>Сложность:</strong> <span class="info-value complexity-${project.complexity}">${project.complexity}</span>
            </div>
            <div class="info-item">
                <strong>Зависимости:</strong> <span class="info-value">${project.dependencies ? project.dependencies.length : 'Не определено'}</span>
            </div>
            <div class="info-item">
                <strong>Тестирование:</strong> <span class="info-value ${project.testing ? 'success' : 'error'}">${project.testing ? '✅ Да' : '❌ Нет'}</span>
            </div>
        `;
        
        // Populate recommendations
        const recommendations = document.getElementById('recommendations');
        const recs = results.recommendations || [];
        if (recs.length > 0) {
            recommendations.innerHTML = recs.map(rec => `
                <div class="recommendation-item ${rec.priority}">
                    <strong>${rec.type}:</strong> ${rec.message}
                </div>
            `).join('');
        } else {
            recommendations.innerHTML = '<div class="info-item">✅ Рекомендаций нет</div>';
        }
        
        // Populate pipeline code with syntax highlighting
        const pipelineContent = results.pipeline_content || results.pipeline;
        document.getElementById('pipelineCode').innerHTML = `
            <div class="code-block">
                <div class="fix-indicator" style="margin-bottom: 15px;">
                    🔧 Сгенерированный CI/CD пайплайн
                </div>
                <pre><code>${pipelineContent}</code></pre>
            </div>
        `;
        
        // Add download functionality
        this.setupDownloadButton(results.platform || 'github-actions');
        
        // Scroll to results
        document.getElementById('results').scrollIntoView({ behavior: 'smooth' });
    }

    setupDownloadButton(platform) {
        const downloadBtn = document.querySelector('.btn-download');
        downloadBtn.onclick = () => {
            window.open(`/api/download/${platform}`, '_blank');
        };
    }

    showProjectPreview(url) {
        // Show a preview of the GitHub repository
        const urlParts = url.split('/');
        const owner = urlParts[3];
        const repo = urlParts[4];
        
        this.showNotification(`Репозиторий: ${owner}/${repo}`, 'info');
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Style the notification
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            z-index: 10000;
            animation: slideIn 0.3s ease;
            max-width: 300px;
        `;
        
        // Set background color based on type
        const colors = {
            success: '#28a745',
            error: '#dc3545',
            info: '#17a2b8',
            warning: '#ffc107'
        };
        notification.style.background = colors[type] || colors.info;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    simulateDelay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Add CSS for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .info-item {
        margin-bottom: 0.5rem;
        padding: 0.5rem;
        background: white;
        border-radius: 4px;
    }
    
    .recommendation-item {
        margin-bottom: 0.5rem;
        padding: 0.5rem;
        border-radius: 4px;
        border-left: 4px solid;
    }
    
    .recommendation-item.high {
        background: #ffebee;
        border-left-color: #f44336;
    }
    
    .recommendation-item.medium {
        background: #fff3e0;
        border-left-color: #ff9800;
    }
    
    .recommendation-item.low {
        background: #e8f5e8;
        border-left-color: #4caf50;
    }
`;
document.head.appendChild(style);

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new AmazingAutomataWeb();
});
