// Amazing Automata Web Interface JavaScript - Netlify Version

class AmazingAutomataWeb {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupUploadOptions();
        this.setupSmoothScrolling();
        this.setupMobileMenu();
    }

    setupEventListeners() {
        // Upload form submission
        document.getElementById('uploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleFormSubmission();
        });

        // File input change
        document.getElementById('folderInput').addEventListener('change', (e) => {
            this.handleFileSelection(e);
        });

        // GitHub URL input
        document.getElementById('githubUrl').addEventListener('input', (e) => {
            this.handleGitHubUrl(e);
        });

        // Fetch GitHub button
        document.querySelector('.btn-fetch').addEventListener('click', (e) => {
            this.fetchGitHubRepo();
        });
    }

    setupUploadOptions() {
        const uploadOptions = document.querySelectorAll('.upload-option');
        
        uploadOptions.forEach(option => {
            option.addEventListener('click', (e) => {
                // Remove active class from all options
                uploadOptions.forEach(opt => opt.classList.remove('active'));
                
                // Add active class to clicked option
                option.classList.add('active');
                
                // Show/hide appropriate inputs
                const type = option.dataset.type;
                this.toggleInputs(type);
            });
        });
    }

    setupSmoothScrolling() {
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    setupMobileMenu() {
        const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
        const mobileMenu = document.querySelector('.mobile-menu');
        
        if (mobileMenuToggle && mobileMenu) {
            mobileMenuToggle.addEventListener('click', () => {
                mobileMenu.style.display = mobileMenu.style.display === 'flex' ? 'none' : 'flex';
            });
            
            // Close mobile menu when clicking on links
            mobileMenu.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    mobileMenu.style.display = 'none';
                });
            });
            
            // Close mobile menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!mobileMenuToggle.contains(e.target) && !mobileMenu.contains(e.target)) {
                    mobileMenu.style.display = 'none';
                }
            });
        }
    }

    toggleInputs(type) {
        const fileInputGroup = document.querySelector('.folder-input');
        const githubInputGroup = document.querySelector('.github-input');
        
        console.log('Toggling inputs to type:', type);
        console.log('File input group:', fileInputGroup);
        console.log('GitHub input group:', githubInputGroup);
        
        if (type === 'file') {
            if (fileInputGroup) fileInputGroup.style.display = 'block';
            if (githubInputGroup) githubInputGroup.style.display = 'none';
        } else if (type === 'github') {
            if (fileInputGroup) fileInputGroup.style.display = 'none';
            if (githubInputGroup) githubInputGroup.style.display = 'block';
        }
    }

    handleFileSelection(e) {
        const files = e.target.files;
        if (files.length > 0) {
            const fileName = files[0].name;
            const fileInfo = document.querySelector('.file-info');
            fileInfo.textContent = `Выбран файл: ${fileName}`;
            fileInfo.style.display = 'block';
        }
    }

    handleGitHubUrl(e) {
        const url = e.target.value;
        const fetchButton = document.querySelector('.btn-fetch');
        
        if (url && this.isValidGitHubUrl(url)) {
            fetchButton.disabled = false;
            fetchButton.textContent = 'Анализировать';
        } else {
            fetchButton.disabled = true;
            fetchButton.textContent = 'Введите корректный GitHub URL';
        }
    }

    isValidGitHubUrl(url) {
        const githubRegex = /^https:\/\/github\.com\/[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+(\/)?$/;
        return githubRegex.test(url);
    }

    async handleFormSubmission() {
        const formData = new FormData();
        const fileInput = document.getElementById('folderInput');
        
        if (fileInput.files.length === 0) {
            this.showError('Пожалуйста, выберите файл для загрузки');
            return;
        }

        // Add all selected files
        for (let file of fileInput.files) {
            formData.append('files', file);
        }

        this.showLoading();
        
        try {
            // Simulate API call with demo data
            await this.simulateAnalysis();
        } catch (error) {
            this.showError('Ошибка при анализе проекта: ' + error.message);
        }
    }

    async fetchGitHubRepo() {
        const githubUrl = document.getElementById('githubUrl').value;
        
        console.log('Fetching GitHub repo:', githubUrl);
        
        if (!githubUrl) {
            this.showError('Пожалуйста, введите GitHub URL');
            return;
        }

        if (!this.isValidGitHubUrl(githubUrl)) {
            this.showError('Пожалуйста, введите корректный GitHub URL');
            return;
        }

        this.showLoading();
        
        try {
            // Simulate GitHub analysis with demo data
            await this.simulateGitHubAnalysis(githubUrl);
        } catch (error) {
            this.showError('Ошибка при анализе GitHub репозитория: ' + error.message);
        }
    }

    async simulateAnalysis() {
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Demo project data
        const demoResults = {
            project_info: {
                language: 'javascript',
                framework: 'react',
                type: 'frontend',
                complexity: 'medium',
                testing: true,
                dependencies: ['react', 'express', 'webpack'],
                structure: {
                    monorepo: false,
                    microservices: false,
                    layered: false,
                    modular: true,
                    dockerized: false
                }
            },
            pipeline_content: `name: CI/CD Pipeline
on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
    - name: Install dependencies
      run: npm install
    - name: Run tests
      run: npm test
    - name: Build project
      run: npm run build

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v3
    - name: Deploy to production
      run: echo "Deploying to production..."`,
            recommendations: [
                'Добавьте автоматическое тестирование в CI/CD пайплайн',
                'Настройте кэширование зависимостей для ускорения сборки',
                'Рассмотрите возможность использования Docker для контейнеризации',
                'Добавьте проверку качества кода с помощью ESLint и Prettier'
            ]
        };
        
        this.showResults(demoResults);
    }

    async simulateGitHubAnalysis(githubUrl) {
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        // Extract repo name from URL
        const repoName = githubUrl.split('/').pop().replace('.git', '');
        
        // Demo data based on popular repositories
        let demoResults;
        
        if (githubUrl.includes('axios')) {
            demoResults = {
                project_info: {
                    language: 'javascript',
                    framework: 'nodejs',
                    type: 'library',
                    complexity: 'medium',
                    testing: true,
                    dependencies: ['follow-redirects', 'proxy-from-env'],
                    structure: {
                        monorepo: false,
                        microservices: false,
                        layered: true,
                        modular: true,
                        dockerized: false
                    }
                },
                pipeline_content: `name: Axios CI/CD Pipeline
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        node-version: [14, 16, 18, 20]
    steps:
    - uses: actions/checkout@v3
    - name: Setup Node.js \${{ matrix.node-version }}
      uses: actions/setup-node@v3
      with:
        node-version: \${{ matrix.node-version }}
    - name: Install dependencies
      run: npm ci
    - name: Run tests
      run: npm test
    - name: Run linting
      run: npm run lint

  publish:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v3
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
    - name: Install dependencies
      run: npm ci
    - name: Build
      run: npm run build
    - name: Publish to npm
      run: npm publish
      env:
        NODE_AUTH_TOKEN: \${{ secrets.NPM_TOKEN }}`,
                recommendations: [
                    'Настройте автоматическую публикацию в npm при создании релиза',
                    'Добавьте проверку совместимости с разными версиями Node.js',
                    'Рассмотрите использование semantic-release для автоматического версионирования'
                ]
            };
        } else if (githubUrl.includes('flask')) {
            demoResults = {
                project_info: {
                    language: 'python',
                    framework: 'flask',
                    type: 'web',
                    complexity: 'medium',
                    testing: true,
                    dependencies: ['werkzeug', 'jinja2', 'click'],
                    structure: {
                        monorepo: false,
                        microservices: false,
                        layered: true,
                        modular: true,
                        dockerized: false
                    }
                },
                pipeline_content: `name: Flask CI/CD Pipeline
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.8, 3.9, 3.10, 3.11]
    steps:
    - uses: actions/checkout@v3
    - name: Setup Python \${{ matrix.python-version }}
      uses: actions/setup-python@v4
      with:
        python-version: \${{ matrix.python-version }}
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install pytest
    - name: Run tests
      run: pytest
    - name: Run linting
      run: |
        pip install flake8
        flake8 . --count --select=E9,F63,F7,F82 --show-source --statistics

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v3
    - name: Deploy to production
      run: echo "Deploying Flask app to production..."`,
                recommendations: [
                    'Настройте автоматическое тестирование с pytest',
                    'Добавьте проверку безопасности с помощью bandit',
                    'Рассмотрите использование Docker для контейнеризации приложения'
                ]
            };
        } else if (githubUrl.includes('gin')) {
            demoResults = {
                project_info: {
                    language: 'go',
                    framework: 'gin',
                    type: 'web',
                    complexity: 'medium',
                    testing: true,
                    dependencies: ['github.com/gin-gonic/gin'],
                    structure: {
                        monorepo: false,
                        microservices: false,
                        layered: true,
                        modular: true,
                        dockerized: false
                    }
                },
                pipeline_content: `name: Gin CI/CD Pipeline
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        go-version: [1.18, 1.19, 1.20]
    steps:
    - uses: actions/checkout@v3
    - name: Setup Go \${{ matrix.go-version }}
      uses: actions/setup-go@v3
      with:
        go-version: \${{ matrix.go-version }}
    - name: Install dependencies
      run: go mod download
    - name: Run tests
      run: go test ./...
    - name: Run linting
      run: |
        go install golang.org/x/lint/golint@latest
        golint ./...
    - name: Build
      run: go build -v ./...

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v3
    - name: Setup Go
      uses: actions/setup-go@v3
      with:
        go-version: '1.20'
    - name: Build binary
      run: go build -o app .
    - name: Deploy
      run: echo "Deploying Go application..."`,
                recommendations: [
                    'Настройте автоматическое тестирование с go test',
                    'Добавьте проверку качества кода с golint и go vet',
                    'Рассмотрите использование Docker для контейнеризации'
                ]
            };
        } else {
            // Generic demo data
            demoResults = {
                project_info: {
                    language: 'unknown',
                    framework: 'unknown',
                    type: 'unknown',
                    complexity: 'low',
                    testing: false,
                    dependencies: [],
                    structure: {
                        monorepo: false,
                        microservices: false,
                        layered: false,
                        modular: false,
                        dockerized: false
                    }
                },
                pipeline_content: `name: Generic CI/CD Pipeline
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Build step
      run: echo "Building project..."
    - name: Test step
      run: echo "Running tests..."`,
                recommendations: [
                    'Добавьте файлы конфигурации для определения типа проекта',
                    'Настройте автоматическое тестирование',
                    'Рассмотрите использование Docker для контейнеризации'
                ]
            };
        }
        
        this.showResults(demoResults);
    }

    showLoading() {
        const resultsSection = document.getElementById('results');
        resultsSection.innerHTML = `
            <div class="loading-container">
                <div class="loading-spinner"></div>
                <h3>Анализируем ваш проект...</h3>
                <p>Это может занять несколько секунд</p>
            </div>
        `;
        resultsSection.style.display = 'block';
        resultsSection.scrollIntoView({ behavior: 'smooth' });
    }

    showError(message) {
        const resultsSection = document.getElementById('results');
        resultsSection.innerHTML = `
            <div class="error-container">
                <div class="error-icon">⚠️</div>
                <h3>Ошибка</h3>
                <p>${message}</p>
                <button onclick="location.reload()" class="btn btn-primary">Попробовать снова</button>
            </div>
        `;
        resultsSection.style.display = 'block';
        resultsSection.scrollIntoView({ behavior: 'smooth' });
    }

    showResults(results) {
        const resultsSection = document.getElementById('results');
        
        // Format project info
        const projectInfo = results.project_info;
        const language = projectInfo.language || 'Не определен';
        const framework = projectInfo.framework || 'Не определен';
        const type = projectInfo.type || 'Не определен';
        const complexity = projectInfo.complexity || 'Не определена';
        const testing = projectInfo.testing ? 'Да' : 'Нет';
        const dependencies = projectInfo.dependencies || [];
        
        // Format recommendations
        const recommendations = results.recommendations || [];
        const recommendationsHtml = recommendations.map(rec => `<li>${rec}</li>`).join('');
        
        // Populate pipeline code with syntax highlighting
        const pipelineContent = results.pipeline_content || results.pipeline;
        
        resultsSection.innerHTML = `
            <div class="results-container">
                <div class="results-header">
                    <h2>Результаты анализа</h2>
                    <div class="success-indicator">
                        ✅ Анализ завершен успешно
                    </div>
                </div>
                
                <div class="results-grid">
                    <div class="project-info">
                        <h3>Информация о проекте</h3>
                        <div class="info-grid">
                            <div class="info-item">
                                <span class="info-label">Язык программирования:</span>
                                <span class="info-value">${language}</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Фреймворк:</span>
                                <span class="info-value">${framework}</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Тип проекта:</span>
                                <span class="info-value">${type}</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Сложность:</span>
                                <span class="info-value">${complexity}</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Тестирование:</span>
                                <span class="info-value">${testing}</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Зависимости:</span>
                                <span class="info-value">${dependencies.length} пакетов</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="pipeline-section">
                        <h3>Сгенерированный CI/CD пайплайн</h3>
                        <div class="code-block">
                            <div class="fix-indicator" style="margin-bottom: 15px;">
                                🔧 Сгенерированный CI/CD пайплайн
                            </div>
                            <pre><code>${pipelineContent}</code></pre>
                        </div>
                    </div>
                    
                    <div class="recommendations">
                        <h3>Рекомендации</h3>
                        <ul>
                            ${recommendationsHtml}
                        </ul>
                    </div>
                </div>
                
                <div class="results-actions">
                    <button onclick="this.downloadPipeline('${pipelineContent.replace(/'/g, "\\'")}')" class="btn btn-primary">
                        <i class="fas fa-download"></i> Скачать пайплайн
                    </button>
                    <button onclick="location.reload()" class="btn btn-secondary">
                        <i class="fas fa-refresh"></i> Анализировать другой проект
                    </button>
                </div>
            </div>
        `;
        
        resultsSection.style.display = 'block';
        resultsSection.scrollIntoView({ behavior: 'smooth' });
    }

    downloadPipeline(pipelineContent) {
        const blob = new Blob([pipelineContent], { type: 'text/yaml' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'ci-cd-pipeline.yml';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AmazingAutomataWeb();
});