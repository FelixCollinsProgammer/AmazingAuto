# Amazing Automata - Netlify Static Site

Это статическая версия сайта Amazing Automata, адаптированная для деплоя на Netlify.

## Особенности

- ✅ Полностью статический сайт (без серверной части)
- ✅ Симуляция API для демонстрации функциональности
- ✅ Адаптивный дизайн
- ✅ Современный UI с зеленой темой
- ✅ Поддержка загрузки файлов и GitHub URL

## Структура файлов

```
netlify_site/
├── index.html          # Главная страница
├── _redirects          # Netlify redirects для SPA
├── static/
│   ├── css/
│   │   └── style.css   # Стили
│   └── js/
│       └── script.js   # JavaScript с симуляцией API
└── README.md           # Этот файл
```

## Деплой на Netlify

1. Зайдите на [app.netlify.com](https://app.netlify.com)
2. Нажмите "New site from Git" или "Deploy manually"
3. Загрузите папку `netlify_site` или подключите Git репозиторий
4. Сайт будет автоматически задеплоен

## Функциональность

### Демо режим
- При загрузке файлов показывается демо-анализ React проекта
- При вводе GitHub URL показывается анализ в зависимости от репозитория:
  - `axios` → JavaScript библиотека
  - `flask` → Python веб-фреймворк  
  - `gin` → Go веб-фреймворк
  - Другие → Общий шаблон

### Возможности
- 📁 Загрузка файлов проекта
- 🔗 Анализ GitHub репозиториев
- 📊 Отображение информации о проекте
- 🔧 Генерация CI/CD пайплайнов
- 💡 Рекомендации по улучшению
- 📥 Скачивание сгенерированных пайплайнов

## Технологии

- HTML5
- CSS3 (Flexbox, Grid, Animations)
- Vanilla JavaScript (ES6+)
- Font Awesome иконки
- Google Fonts

## Браузерная поддержка

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+
